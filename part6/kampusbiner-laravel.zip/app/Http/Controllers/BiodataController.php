<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Biodata;

class BiodataController extends Controller
{
    
    public function getBiodata(Request $request){
        
        return Biodata::where("nama", "=", $request->input("nama"))->first()->biodata;

    }

}
