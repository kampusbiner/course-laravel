<?php $__env->startSection("content"); ?>
<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Blank Page</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.main", ["page" => "blank"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dataku\Course KampusBiner\kampusbiner-laravel\resources\views/blank.blade.php ENDPATH**/ ?>