<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BiodataController extends Controller
{
    
    public function getBiodata(Request $request){
        switch($request->input("nama")){
            case "andi":
                return "Bertempat tinggal di Bali";
            case "banu":
                return "Umur 24 tahun, sudah kuliah";
            case "caca":
                return "Umur 28 tahun, sudah menikah, tinggal di Bandung";
            case "deni":
                return "Bersekolah di Jakarta sejak tahun 1990";
            case "endi":
                return "Bertempat tinggal di Manado";
            case "fani":
                return "Bersekolah di Jambi hingga umur 20 tahun sebelum berpindah ke Surabaya";
            case "gani":
                return "Berumur 30 tahun";
        }

    }

}
